package com.example.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SupportActivity extends AppCompatActivity {
EditText txtname,txtphone,txtmail,txtnote;
Button btnsend;
DatabaseReference reff3;
Member member;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);
        txtname=(EditText)findViewById(R.id.txtname);
        txtphone=(EditText)findViewById(R.id.txtphone);
        txtmail=(EditText)findViewById(R.id.txtmail);
        txtnote=(EditText)findViewById(R.id.txtnote);
        btnsend=(Button)findViewById(R.id.btnsend);
        member=new Member();
        reff3= FirebaseDatabase.getInstance().getReference().child("Member");
        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int phonea=Integer.parseInt(txtphone.getText().toString().trim());

                member.setName(txtname.getText().toString().trim());
                member.setPhone(phonea);
                member.setMail(txtmail.getText().toString().trim());
                member.setNote(txtnote.getText().toString().trim());

                reff3.push().setValue(member);
                Toast.makeText(SupportActivity.this,"Thank you for your notes",Toast.LENGTH_LONG).show();
            }
        });
    }
}
