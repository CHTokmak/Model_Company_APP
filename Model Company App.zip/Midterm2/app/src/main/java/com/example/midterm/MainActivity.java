package com.example.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void gonder(View view) {

       Intent ıntent= new Intent(getApplicationContext(),HistoryActivity.class);
       startActivity(ıntent);

    }


    public void git(View view) {

        Intent form = new Intent(getApplicationContext(),SupportActivity.class);
        startActivity(form);

    }

    public void gel(View view) {

        Intent vision = new Intent(getApplicationContext(),VisionActivity.class);
        startActivity(vision);

    }

    public void go(View view) {

        Intent adres = new Intent(getApplicationContext(),AdresActivity.class);
        startActivity(adres);

    }
}
